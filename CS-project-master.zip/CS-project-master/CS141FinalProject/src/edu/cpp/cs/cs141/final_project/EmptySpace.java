/**
 * CS 141: Intro to Programming and Problem Solving
 * Professor: Edwin Rodríguez
 *
 * Description of assignment:
 * 		Create and design a turned based Spy vs Ninja game by using 
 * 		Object oriented techniques and follows the specifications 
 * 		based on the rubric. 
 * Team: Spirit Coders 
 * 		Wing Hung Lau
 * 		Michael Tang
 * 		Donovan Gonzalez
 * 		Lynn Nguyen
 * 		Xinyuan Wang
 * 		Connor Chase
 */
package edu.cpp.cs.cs141.final_project;

/** 
 * This class represents all the empty spaces located on the grid {link @Grid}.
 *
 * @author Connor Chase
 */
public class EmptySpace extends SquareObject {

	
	public EmptySpace(int x,int y)
	
	{
		super(x,y);
	}
	


	@Override
	public String toString(boolean isDebug) {
		if(isDebug||this.isVisible())
			return "[ ]";
		else
			return "[*]";
	}

	
	
}
