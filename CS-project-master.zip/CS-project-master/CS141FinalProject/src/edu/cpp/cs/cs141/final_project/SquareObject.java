/**
 * CS 141: Intro to Programming and Problem Solving
 * Professor: Edwin Rodríguez
 *
 * Description of assignment:
 * 		Create and design a turned based Spy vs Ninja game by using 
 * 		Object oriented techniques and follows the specifications 
 * 		based on the rubric. 
 * Team: Spirit Coders 
 * 		Wing Hung Lau
 * 		Michael Tang
 * 		Donovan Gonzalez
 * 		Lynn Nguyen
 * 		Xinyuan Wang
 * 		Connor Chase
 */
package edu.cpp.cs.cs141.final_project;

import java.io.Serializable;

/** 
 * This class represents all the object located on the grid {link @Grid}.
 *
 * @author Connor Chase
 */
public abstract class SquareObject implements Serializable {
	
	private int x;
	private int y;
	private boolean isVisible;
	
	public SquareObject(){}
	
	public SquareObject(int x,int y)
	{
		setLocation(x,y);
	}

  /**
  * Assigns the location of the objects on the grid.
  */
  public void setLocation(int x,int y)
  {
	  this.x=x;
	  this.y=y;
  }
  
  /**
  * Returns the individual x and y coordinates of the object.
  */
  public int getX()
  {
	  return x;
  }
  
  public int getY()
  {
	  return y;
  }
  
  public boolean isVisible()
  {
	  return isVisible;
  }
  
  public void visionControl(boolean isVisible)
  {
	  this.isVisible=isVisible;
  }

  
  public abstract String toString(boolean isDebug);
  
  
}
